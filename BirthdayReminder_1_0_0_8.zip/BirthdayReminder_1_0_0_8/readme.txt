commandline arguments:
/email - force to send to email (don't show on the screen)


Code page (������ ��������� https://msdn.microsoft.com/en-us/library/system.text.encoding(v=vs.110).aspx )
CodePage = 1251

CSV fields delimiter:
CSVdelimiter = ;

CSV file with data:
DatabaseFile = birthdays.csv

Date delimiter:
DateDelimiter = .

Date format[3 letters for "Y"ear, "M"onth, "D"ay]
DateFormat = DMY

Advance days to inform:
WarnPeriod = 40

Font size:
FontSize = 10

Show on the screen or send to e-mail[True/False]:
SendEmail = False

SMTP address:
SmtpAddress = smtp.googlemail.com

SMTP port:
SmtpPort = 587

Use SMTP SSL [True/False]:
SmtpSSL = True

SMTP login:
SmtpLogin = ******@gmail.com

SMTP password:
SmtpPassword = ******

Mail address To (could be a list divided with [CSVdelimiter]):
EmailTo = ******@gmail.com

Mail subject:
EmailSubject = BirthDay reminder
